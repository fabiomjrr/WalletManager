create procedure getWalletsByUsersId @id int
as 
begin
	select
        w1_0.idWallet,
        w1_0.balanceWallet,
        w1_0.codeWallet,
        w1_0.idUser 
    from
        Wallet w1_0 
    where
        w1_0.idUser= @id
end
go

