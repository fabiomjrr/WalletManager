create procedure updateWalletOrganizations 
 @budgetAsigned decimal(15,2),
 @creationOrganization datetime,
 @endPeriod datetime,
 @idDuration int,
 @idWallet int,
 @idWalletCategory int,
 @OrganizerName varchar(30),
 @percentageFromWallet decimal(5,2),
 @startPeriod datetime,
 @idOrganizer int
as 
begin 
update WalletOrganizations 
    set
        budgetAsigned=@budgetAsigned,
        creationOrganization=@creationOrganization,
        endPeriod= @endPeriod,
        idDuration=@idDuration,
        idWallet=@idWallet,
        idWalletCategory=@idWalletCategory,
        OrganizerName=@OrganizerName,
        percentageFromWallet=@percentageFromWallet,
        startPeriod=@startPeriod
    where
        idOrganizer=@idOrganizer
end
go

