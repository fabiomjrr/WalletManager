create procedure getAllTypeIncomes
as 
begin 
	select
        ti1_0.idTypeIncome,
        ti1_0.isVisible,
        ti1_0.typeIncome 
    from
        TypeIncomes ti1_0
end
go

