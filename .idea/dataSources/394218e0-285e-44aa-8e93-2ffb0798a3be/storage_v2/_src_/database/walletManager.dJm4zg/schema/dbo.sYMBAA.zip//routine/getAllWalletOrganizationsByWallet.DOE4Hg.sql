create procedure getAllWalletOrganizationsByWallet @id int
as 
begin	
	 select
        wo1_0.idOrganizer,
        wo1_0.budgetAsigned,
        wo1_0.creationOrganization,
        wo1_0.endPeriod,
        wo1_0.idDuration,
        wo1_0.idWallet,    
        wo1_0.idWalletCategory,
        wo1_0.OrganizerName,
        wo1_0.percentageFromWallet,
        wo1_0.startPeriod 
    from
        WalletOrganizations wo1_0
    Where idWallet = @id    
end
go

