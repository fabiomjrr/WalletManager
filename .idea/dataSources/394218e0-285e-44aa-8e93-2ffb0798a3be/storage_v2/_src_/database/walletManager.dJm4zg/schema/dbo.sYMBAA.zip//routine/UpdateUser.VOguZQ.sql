CREATE    PROCEDURE UpdateUser    
    @nameUsers VARCHAR(50),
    @lastnamteUsers VARCHAR(50),
    @emailUser VARCHAR(100),
    @passUser VARCHAR(100),
    @statusUser BIT,
    @idUsers INT
AS
BEGIN
    UPDATE walletManager.dbo.Users
    SET
        nameUsers = @nameUsers,
        lastnamteUsers = @lastnamteUsers,
        emailUser = @emailUser,
        passUser = @passUser,
        statusUser = @statusUser
    WHERE idUsers = @idUsers;
END;
go

