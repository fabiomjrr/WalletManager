create procedure getAllDurations 
as 
begin 
	select
        wc1_0.idWalletCategory,
        wc1_0.CategoryName 
    from
        WalletCategories wc1_0
end
go

