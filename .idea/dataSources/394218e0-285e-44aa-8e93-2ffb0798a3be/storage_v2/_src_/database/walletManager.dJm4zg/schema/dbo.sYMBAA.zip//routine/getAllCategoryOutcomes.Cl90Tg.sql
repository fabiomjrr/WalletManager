create procedure getAllCategoryOutcomes
as 
Begin
	select
        co1_0.idCategoryOutcome,
        co1_0.categoryOutcome,
        co1_0.isVisible 
    from
        CategoryOutcomes co1_0
END
go

