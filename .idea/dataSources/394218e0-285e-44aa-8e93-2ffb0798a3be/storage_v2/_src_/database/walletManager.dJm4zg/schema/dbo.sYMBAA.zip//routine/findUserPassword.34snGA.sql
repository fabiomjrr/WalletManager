CREATE PROCEDURE findUserPassword
    @Email NVARCHAR(255)
AS
BEGIN
    SELECT passUser 
    FROM Users
    WHERE emailUser = @Email;
END
go

