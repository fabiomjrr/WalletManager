create procedure createBudget @idOrganizer int, @idWallet int
as 
begin 
	insert 
    into
        WalletBudgets (idOrganizer, idWallet) 
    values
        (@idOrganizer, @idWallet)
end
go

