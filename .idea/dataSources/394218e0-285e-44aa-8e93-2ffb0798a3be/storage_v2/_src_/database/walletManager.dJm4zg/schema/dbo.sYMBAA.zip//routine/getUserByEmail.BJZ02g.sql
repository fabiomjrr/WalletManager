Create procedure getUserByEmail @email Varchar(100)
as 
begin 
	Select * from Users where emailUser = @email
end
go

