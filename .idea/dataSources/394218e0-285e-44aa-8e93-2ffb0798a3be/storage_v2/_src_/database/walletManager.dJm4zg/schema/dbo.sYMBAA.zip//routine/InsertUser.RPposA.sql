CREATE PROCEDURE InsertUser
    @nameUsers VARCHAR(50),
    @lastnamteUsers VARCHAR(50),
    @emailUser VARCHAR(100),
    @passUser VARCHAR(100),
    @statusUser BIT = 1
AS
BEGIN
    INSERT INTO walletManager.dbo.Users (
        nameUsers,
        lastnamteUsers,
        emailUser,
        passUser,
        statusUser
    )
    VALUES (
        @nameUsers,
        @lastnamteUsers,
        @emailUser,
        @passUser,
        @statusUser
    );
END;
go

